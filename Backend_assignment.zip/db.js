const mongoose = require('mongoose');

// Replace the connection string with your MongoDB Atlas URL
const mongoURI = 'mongodb://dbSandesh:<Kamala>@ac-3c21etb-shard-00-00.mlnpdyy.mongodb.net:27017,ac-3c21etb-shard-00-01.mlnpdyy.mongodb.net:27017,ac-3c21etb-shard-00-02.mlnpdyy.mongodb.net:27017/?replicaSet=atlas-9gvbuc-shard-0&ssl=true&authSource=admin';

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
  });

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

module.exports = mongoose;
